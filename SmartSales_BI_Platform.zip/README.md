# SmartSales - Business Intelligence Platform

## Overview
SmartSales is an interactive single-page Business Intelligence dashboard demonstrating Descriptive, Diagnostic, Predictive, and Prescriptive Analytics using sample corporate sales data.

## Features Included:
- **Descriptive Analytics:** KPI summary cards, revenue/profit trajectory line charts, and regional pie charts.
- **Diagnostic Analytics:** Profit margin breakdowns by product line and root cause diagnostic summaries.
- **Predictive Analytics:** Interactive 2027 scenario forecasting simulator using target growth and marketing investment sliders.
- **Prescriptive Analytics:** Dynamic AI-driven strategy recommendations based on active data metrics.
- **Exporting:** Integrated ZIP package generator.

## Usage
Simply double-click `index.html` to open the platform in any browser. No web server required.
